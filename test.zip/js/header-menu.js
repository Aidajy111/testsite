document.querySelectorAll('.sam_burger')[0].onclick = function() {
    document.querySelectorAll('.Sam_ahaha_block_burger')[0].classList.toggle('burger-Aactive');
    document.querySelectorAll('.fixed_heder_menu')[0].classList.toggle('Mennu-Aactive');
}