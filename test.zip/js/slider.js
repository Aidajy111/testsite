$('.multiple_items_slidesBL9').slick({
  dots: false,
  arrows: false,
  slidesToShow: 6,
  centerMode: false,
  variableWidth: true,
  slidesToScroll: 3
});


