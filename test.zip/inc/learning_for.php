        <!--bl5 markup-->
        <div class="mainContent_senterBL5">
            <div class="mainContent_senterBL5_center">
                <div class="mainContent_senterBL5_discriptionMain">
                    <div class="mainContent_senterBL5_discr_label"><?php echo $fieldsArr['for_title'];?></div>
                    <div class="mainContent_senterBL5_discr_Text"><?php echo $fieldsArr['for_description'];?></div>
                </div>
            </div>
        </div>
        <!--bl5_v2 markup-->
        <div class="mainContent_senterBL5_v2">
            <div class="mainContent_senterBL5_center_v2">
                <div class="BL5Center_v2">
                    <div>
                        <?php if($fieldsArr['for_text_left_title']):?>
                        <div class="mainContent_senterBL5_discr_label_v2"><?php echo $fieldsArr['for_text_left_title'];?></div>
                        <?php endif;?>
                        <div class="mainContent_senterBL5_discr_Text_v2">
                            <?php echo $fieldsArr['for_text_left'];?>
                        </div>
                    </div>
                </div>

                <div class="BL5Center_v2_ig_discription">
                    <div class="BL5Center_v2_ig_discription_contetn_block">
                        <div class="BL5Center_v2_ig_discr_Samcont_block">
                            <div class="BL5_v2_ig_textoo">
                                <?php echo $fieldsArr['for_text_right'];?>
                            </div>
                            <?php if($fieldsArr['for_button_show']):?>
                            <div class="BL5_v2_ig_BUtnS">
                                <a href="<?php echo $fieldsArr['for_button_link'];?>"><?php echo $fieldsArr['for_button_text'];?></a>
                            </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>