<?php 
if(!empty($fieldsArr['gallery_shortcode'])){
echo do_shortcode($fieldsArr['gallery_shortcode']);
}

?>