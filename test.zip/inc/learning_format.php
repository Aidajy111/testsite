            <!--bl3 main markup center-->
            <div class="markup_bl3_center_ion">
                <div class="markup_bl3_center_ion_correct">
                    <div class="markup_bl3_label"><div><?php echo $fieldsArr['format_title'];?></div></div>
                    <?php if(!empty($fieldsArr['formates'])):?>
                    <?php foreach($fieldsArr['formates'] as $format):?>
                    <div class="markup_bl3_BLOCK">
                        <div class="markup_bl3_podBLOCKs">
                            <img src="<?php echo $format['icon']['url'];?>" alt="<?php echo $format['icon']['alt'];?>">
                            <div class="markup_bl3_podLabelText"><?php echo $format['title'];?></div>
                            <div class="markup_bl3_podDiscriptionText"><?php echo $format['description'];?></div>
                        </div>
                    </div>
                    <?php endforeach;?>
                    <?php endif;?>
                </div>
            </div>