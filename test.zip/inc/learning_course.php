        <!--bl1 markup-->
        <div class="mainContent_senter">
            <div class="content_block_1gn">
                <div class="block_content_1_all_dop">
                    <img src="<?php echo $fieldsArr['course_img']['url'];?>" alt="<?php echo $fieldsArr['course_img']['alt'];?>">
                </div>

                <div class="block_content_1_all">
                    <div class="blck_1_contTop"><span><?php echo $fieldsArr['course_title'];?></span></div>
                    <div class="blck_1_contDown">
                        <div class="blck_1_Text"><?php echo $fieldsArr['course_description'];?></div>
                        <div class="blck_1_Icons">
                            <?php if ($fieldsArr['course_format']):?>
                            <div class="C_detailS_bl1_imgs course__detail_bl1_img">
                                <img src="<?php echo get_template_directory_uri();?>/imgs/li.course__detail-item.png">
                                <div>
                                    <div class="C_details_labelBl1">Формат</div>
                                    <div class="C_details_contextBl1"><?php echo $fieldsArr['course_format'];?></div>
                                </div>
                            </div>
                            <?php endif;?>
                            <?php if ($fieldsArr['course_duration']):?>
                            <div class="C_detailS_bl1_imgs time__detail_bl1_img">
                                <img src="<?php echo get_template_directory_uri();?>/imgs/li.time__detail-item.png">
                                <div>
                                    <div class="C_details_labelBl1">Длительность</div>
                                    <div class="C_details_contextBl1"><?php echo $fieldsArr['course_duration'];?></div>
                                </div>
                            </div>
                            <?php endif;?>
                            <?php if ($fieldsArr['course_start']):?>
                            <div class="C_detailS_bl1_imgs date__detail_bl1_img">
                                <img src="<?php echo get_template_directory_uri();?>/imgs/li.date__detail-item.png">
                                <div>
                                    <div class="C_details_labelBl1">Начало</div>
                                    <div class="C_details_contextBl1"><?php echo $fieldsArr['course_start'];?></div>
                                </div>
                            </div>
                            <?php endif;?>
                        </div>
                        <?php if($fieldsArr['course_button_show']):?>
                        <div class="blck_1_Butns"><a href="<?php echo $fieldsArr['course_button_link'];?>"><?php echo $fieldsArr['course_button_text'];?></a></div>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>