            <!--bl2 main markup center-->
            <div class="markup_bl2_center_ion">
                <div class="markup_bl2_center_ion_correct">
                    <div class="markup_bl2_BottomImg_dopa">
                        <img src="<?php echo $fieldsArr['info_img']['url'];?>">
                        <?php if($fieldsArr['info_button_show']):?>
                        <div class="blck_2_Butns">
                            <a href="<?php echo $fieldsArr['info_button_link'];?>"><img src="<?php echo get_template_directory_uri();?>/imgs/span.play__icon.png"> <span><?php echo $fieldsArr['info_button_text'];?></span></a>
                        </div>
                        <?php endif;?>
                    </div>
                    <div class="markup_bl2_TopText">
                        <div class="markup_bl2_TopText_label"><div><?php echo $fieldsArr['info_title'];?></div></div>
                        <div class="markup_bl2_TopText_discription"><?php echo $fieldsArr['info_description'];?></div>
                    </div>
                    <div class="markup_bl2_BottomImg">
                        <img src="<?php echo $fieldsArr['info_img']['url'];?>">
                        <?php if($fieldsArr['info_button_show']):?>
                        <div class="blck_2_Butns">
                            <a href="<?php echo $fieldsArr['info_button_link'];?>"><img src="<?php echo get_template_directory_uri();?>/imgs/span.play__icon.png"> <span><?php echo $fieldsArr['info_button_text'];?></span></a>
                        </div>
                        <?php endif;?>
                    </div>
                </div>
            </div>