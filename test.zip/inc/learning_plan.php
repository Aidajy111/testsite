<?php
$stages_count = count($fieldsArr['plan_stages']);
?>

        <!--bl6 markup-->
        <div class="mainContent_senterBL6">
            <div class="mainContent_senterBL6_AllTheSides">
                <div class="mainContent_senterBL6_LeftSide">
                    <div class="BL6_LeftSide_DublContent">
                        <div class="BL6_LeftSide_ForTexts">
                            <div class="BL6_ig_Label"><?php echo $fieldsArr['plan_title'];?></div>
                            <div class="BL6_ig_textoo">
                                <?php echo $fieldsArr['plan_description'];?>
                            </div>
                            <?php if($fieldsArr['plan_button_show']):?>
                            <div class="BL6_ig_BUtnS">
                                <a href="<?php echo $fieldsArr['plan_button_link'];?>"><?php echo $fieldsArr['plan_button_text'];?></a>
                            </div>
                            <?php endif;?>
                        </div>

                        <div class="BL6_LeftSide_ForImg"><img src="#"></div>
                    </div>
                </div>

                <div class="mainContent_senterBL6_CenterSide"><img src="<?php echo get_template_directory_uri();?>/imgs/picture.week__image.png"></div>

                <div class="mainContent_senterBL6_Rightide">
                    <div class="orient"></div>
                    <?php if ($stages_count > 0):?>
                    <div class="senterBL6_Rightide_ForPages orientN">
                        <?php for ($i = 1; $i <= $stages_count; $i++):?>
                        <?php if ($i == 1):?>
                        <div class="senterBL6_Rightide_SamPage senterBL6_Rightide_SamPage_active">01</div>
                        <?php else:?>
                        <div class="senterBL6_Rightide_SamPage"><?php echo ($i > 9) ? $i : '0' . $i;?></div>
                        <?php endif;?>
                        <?php endfor;?>
                    </div>

                    <div class="senterBL6_Rightide_ForContent orientN">
                        <?php foreach($fieldsArr['plan_stages'] as $stage):?>
                        <div class="senterBL6_Rightide_ContentBL">
                            <div class="BL6_Rightide_ContentBL_Date"><?php echo $stage['duration'];?></div>
                            <div class="BL6_Rightide_ContentBL_Label"><?php echo $stage['title'];?></div>
                            <div class="BL6_Rightide_ContentBL_TemsBl">
                                <?php echo $stage['text'];?>
                            </div>
                        </div>

                        <?php endforeach;?>
                    </div>
                    <?php endif;?>
                </div>
            </div>
        </div>

        <div class="mainContent_senterBL6_DOPAA">
            <div class="mainContent_senterBL6_DOPAA_left"></div>
            <div class="mainContent_senterBL6_DOPAA_right"></div>
        </div>