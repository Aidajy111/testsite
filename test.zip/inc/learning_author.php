            <!--bl4 main markup center-->
            <div class="markup_bl4_center_ion">
                <div class="markup_bl4_center_ion_correct">
                    <div class="markup_bl4_StatsPlusImg">
                        <div class="markup_bl4_StatsPlus">
                            <div class="markup_bl4_StatsPlusName">
                                <div class="markup_bl4_StatsPlusNameBigerText"><?php echo $fieldsArr['author_name'];?></div>
                                <div class="markup_bl4_StatsPlusNameSmallText"><?php echo $fieldsArr['author_occupation'];?></div>
                            </div>
                            <?php if(!empty($fieldsArr['author_counters'])):?>
                            <div class="markup_bl4_StatsPlustime">
                                <?php foreach($fieldsArr['author_counters'] as $author_counter):?>
                                <div class="markup_bl4_StatsPlusNameBigerText"><?php echo $author_counter['counter'];?></div>
                                <div class="markup_bl4_StatsPlusNameSmallText"><?php echo $author_counter['text'];?></div>
                                <?php endforeach;?>
                            </div>
                            <?php endif;?>
                        </div>
                        <div class="markup_bl4_ImgPlus"><img src="<?php echo $fieldsArr['author_img']['url'];?>" alt="<?php echo $fieldsArr['author_img']['alt'];?>"></div>
                    </div>

                    <div class="markup_bl4_discription">
                        <div class="markup_bl4_discription_text markup_bl4_discription_textMARFirst">
                            <div><?php echo $fieldsArr['author_description'];?></div>
                        </div>
                        <div class="markup_bl4_discription_text markup_bl4_discription_textMAR">
                           <?php echo $fieldsArr['author_text'];?>
                        </div>
                        <?php if($fieldsArr['author_social']):?>
                        <div class="markup_bl4_discription_Links markup_bl4_discription_textMAR">
                            <?php if($optionsArr['main_instagram']):?>
                            <div class="markup_bl4_discr_Links_ForButns">
                                <?php if($optionsArr['main_instagram_link']):?>
                                <a href="<?php echo $optionsArr['main_instagram_link'];?>" target="_blank">
                                <?php endif;?>
                                    <div class="markup_bl4_discr_Links_ForButns_Biger">Instagram</div>
                                    <div class="markup_bl4_discr_Links_ForButns_Mini"><?php echo $optionsArr['main_instagram'];?></div>
                                <?php if($optionsArr['main_instagram_link']):?>
                                </a>
                                <?php endif;?>
                            </div>
                            <?php endif;?>
                            <?php if($optionsArr['main_youtube']):?>
                            <div class="markup_bl4_discr_Links_ForButns markup_bl4_discr_Links_ForButn_left">
                                <a href="<?php echo $optionsArr['main_youtube'];?>" target="_blank">
                                    <div class="markup_bl4_discr_Links_ForButns_Biger">YouTube</div>
                                    <div class="markup_bl4_discr_Links_ForButns_Mini">Подписаться</div>
                                </a>
                            </div>
                            <?php endif;?>
                        </div>
                        <?php endif;?>
                    </div>
                </div>
            </div>