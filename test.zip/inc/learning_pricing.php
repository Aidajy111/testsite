        <!--bl8 markup-->
        <div class="mainContent_senterBL8">
            <div class="mainCont_sBL8_align_labelbl"><div class="mainCont_sBL8_Sam_labelbl"><?php echo $fieldsArr['pricing_title'];?></div></div>
            <div class="mainCont_sBL8_align_labelbloks">
                <div class="sBL8_al_labelSambloks">
                    <?php if(!empty($fieldsArr['pricing_prices'])):?>
                    <?php foreach($fieldsArr['pricing_prices'] as $price):?>
                    <div class="sBL8_align_labelSambloks">
                        <div class="sBL8_sam_label sBL8_sam_label_smp1"><span><?php echo $price['title'];?></span></div>
                        <div class="sBL8_sam_Con_box">
                            <div class="sBL8_sam_Con_box_content">
                                <div class="sBL8_sam_Con_box_cont_LabelOO"><?php echo $price['title'];?></div>
                                <div class="sBL8_sam_Con_box_cont_discription">
                                    <?php echo $price['description'];?>
                                </div>
                                <div class="sBL8_sam_Con_box_cont_price"><span><?php echo $price['price'];?></span> руб.</div>
                                <div class="BL8_ig_BUtnS"><a href="<?php echo $price['button_link'];?>"><?php echo $price['button_text'];?></a></div>
                            </div>
                        </div>
                        <div class="sBL8_sam_label_dop sBL8_sam_label_smp1_dop"
                        <?php if(!empty($price['img'])):?>
                            style="background-image: url(<?php echo $price['img']['url'];?>);"
                        <?php endif;?>
                        ></div>
                    </div>

                    <?php endforeach;?>
                    <?php endif;?>
                </div>
            </div>
            <?php if($fieldsArr['pricing_instagram_show'] && $optionsArr['main_instagram']):?>
            <div class="mainCont_sBL8_align_InstLink">
                <div class="mainCont_sBL8_align_InstLink_dopa">
                    <div class="sBL8_align_InstLink_label">Ищи меня в Instagram</div>
                    <div class="sBL8_align_InstLink_SamLink"><span></span>
                        <?php if($optionsArr['main_instagram_link']):?>
                        <a href="<?php echo $optionsArr['main_instagram_link'];?>"><?php echo $optionsArr['main_instagram'];?></a>
                        <?php else:?>
                        <?php echo $optionsArr['main_instagram'];?>
                        <?php endif;?>
                    </div>
                </div>
            </div>
            <?php endif;?>
        </div>