        <!--bl9 slider markup-->
        <?php if(!empty($fieldsArr['gallery'])):?>
        <div class="multiple_items_slidesBL9">
            <?php foreach($fieldsArr['gallery'] as $gallery):?>
            <div class="sam_item_slidesBL9">
                <?php if($fieldsArr['gallery_instagram']):?>
                <a href="<?php echo $fieldsArr['gallery_instagram'];?>" target="_blank"><img src="<?php echo $gallery['url'];?>" class="BL9_imgs"></a>
                <?php else:?>
                <img src="<?php echo $gallery['url'];?>" class="BL9_imgs">
                <?php endif;?>
            </div>
            <?php endforeach;?>
        </div>
        <?php endif;?>