        <!--bl7 markup-->
        <div class="mainContent_senterBL7">
            <div class="mainContent_senterBL7_PodCont"
                <?php if(!empty($fieldsArr['cost_img'])):?>
                style="background-image: url(<?php echo $fieldsArr['cost_img']['url'];?>);"
                <?php endif;?>
            >
                <div class="mainContent_senterBL7_PodCont_text_1">
                    <div class="mainContent_senterBL7_PodCont_text">
                        <div class="mainContent_senterBL7_Sam_text">
                            <div class="BL7_Sam_text_label"><?php echo $fieldsArr['cost_title'];?></div>
                            <?php if($fieldsArr['cost_price']):?>
                            <div class="BL7_Sam_text_price"><span><?php echo $fieldsArr['cost_price'];?></span> руб</div>
                            <?php endif;?>
                            <?php if(!empty($fieldsArr['cost_include'])):?>
                            <div class="BL7_Sam_text_ContList">
                                <?php foreach($fieldsArr['cost_include'] as $key => $cost):?>
                                <div class="BL7_Sam_text_ContListPncts">
                                    <div class="spisok_coorectedBL7"><?php echo ($key >= 9) ? $key + 1 : '0' . ($key + 1);?></div>
                                    <div class="spisok_coorectedBL7_lineee"></div>
                                    <div class="spisok_corTextBL7"><?php echo $cost['text'];?></div>
                                </div>
                                <?php endforeach;?>
                            </div>
                            <?php endif;?>
                            <?php if($fieldsArr['cost_button_show']):?>
                            <div class="BL7_ig_BUtnS_small"><a href="<?php echo $fieldsArr['cost_button_link'];?>"><?php echo $fieldsArr['cost_button_text'];?></a></div>
                            <?php endif;?>
                        </div>
                    </div>

                    <?php if($fieldsArr['cost_button_show']):?>
                    <div class="BL7_ig_BUtnS_biger"><a href="<?php echo $fieldsArr['cost_button_link'];?>"><?php echo $fieldsArr['cost_button_text'];?></a></div>
                    <?php endif;?>
                </div>
            </div>
        </div>